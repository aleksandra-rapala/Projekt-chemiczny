
Klucz 1;45;Klucz 2;500;Klucz 3;300


<svg width="300" height="300" id="svgContainer" style="display: block; margin: auto; height: 300px;">

    <path id="dpie0" style="fill:RGB(0,255,150);
stroke: none" type="arc" d="M 270,150 A 120,120 0 0 1 263.3447133921783,189.40781579896262 L 150,150z"></path>

<path id="dpie1" style="fill:RGB(85,170,150);
stroke: none" type="arc" d="M 263.3447133921783,189.40781579896262 A 120,120 0 1 1 76.43352871289366,55.19507237298602 L 150,150z"></path>

<path id="dpie2" style="fill:RGB(170,85,150);stroke: none" type="arc" d="M 76.43352871289366,55.19507237298602 A 120,120 0 0 1 270,149.99999999999997 L 150,150z"></path>

<text x="244.6595847986861" y="165.9863380966485" style="fill: black;stroke: none;text-anchor: middle" id="text0">Klucz 1 = 45</text>

<text x="94.0066160438264" y="227.97910587546204" style="fill: black;stroke: none;text-anchor: middle" id="text1">Klucz 2 = 500</text>

<text x="192.2261471433887" y="63.78542758080346" style="fill: black;stroke: none;text-anchor: middle" id="text2">Klucz 3 = 300</text>

</svg>