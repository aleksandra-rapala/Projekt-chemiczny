<?php

//stałe dotyczące połączenia z bazą danych

const USERNAME = 'evnwdskutjyzrw';
const PASSWORD = 'ed7e0eccabac5d26098b21716989ba081226633207694b8230bd30f8e5b65074';
const HOST = 'ec2-54-74-95-84.eu-west-1.compute.amazonaws.com';
const DATABASE = 'de8s6bj1vdvuo3';