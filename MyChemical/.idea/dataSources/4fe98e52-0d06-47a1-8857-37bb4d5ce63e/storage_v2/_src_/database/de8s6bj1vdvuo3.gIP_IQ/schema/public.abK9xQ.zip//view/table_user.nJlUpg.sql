create view table_user(id_table, name_table, img_table, img_content_table, id_board) as
SELECT t.id_table,
       t.name_table,
       t.img_table,
       t.img_content_table,
       b.id_board
FROM "table" t
         JOIN "board-table" b USING (id_table);

alter table table_user
    owner to evnwdskutjyzrw;

