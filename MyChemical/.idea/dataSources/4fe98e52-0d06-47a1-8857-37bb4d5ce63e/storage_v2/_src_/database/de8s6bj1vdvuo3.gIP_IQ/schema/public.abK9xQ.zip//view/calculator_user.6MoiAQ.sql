create view calculator_user (id_calculator, name_calculator, img_calculator, endpoint_calculator, id_board) as
SELECT t.id_calculator,
       t.name_calculator,
       t.img_calculator,
       t.endpoint_calculator,
       b.id_board
FROM calculator t
         JOIN "board-calculator" b USING (id_calculator);

alter table calculator_user
    owner to evnwdskutjyzrw;

